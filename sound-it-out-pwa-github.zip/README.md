# Sound It Out! (GitHub Pages Quickstart)

This is a tiny Progressive Web App (PWA) you can host **free** on GitHub Pages.

## How to publish
1) Create a new repository called **sound-it-out** (Public, add a README is OK).
2) Click **Add file → Upload files** and upload all files from this folder (index.html, manifest.json, sw.js, icon.png).
3) Go to **Settings → Pages** → Source: **main** branch, folder: **/(root)** → **Save**.
4) Wait ~1 minute then open: `https://YOUR-USERNAME.github.io/sound-it-out`

## Update later
- Edit files in GitHub and click **Commit** — your site updates automatically.
- If you change file names, also update `sw.js` ASSETS list.

## PWA install
- On Android/desktop Chrome: click the **Install** icon in the address bar.
- On iOS Safari: use **Share → Add to Home Screen**.
